from typing import List
from autogen_agentchat.agents import AssistantAgent, UserProxyAgent
from autogen_agentchat.teams import RoundRobinGroupChat
from autogen_agentchat.conditions import TextMentionTermination
from autogen_ext.models.openai import OpenAIChatCompletionClient
from autogen_core.models import ModelFamily
import json

# --- PROMPT FOR THE QUESTION GENERATOR (Unchanged) ---
QUESTION_GENERATOR_PROMPT = """
You are a hiring manager for an Excel Data Analyst position.
Your task is to generate a list of exactly 10 interview questions.
- 3 questions should be theoretical (e.g., "Explain...")strictly there must be no mcqs.
- 3 questions should be practical/case-study/scenario-based (e.g., "How would you...").
- in total there must be 6 questions.
- The questions must be unique and cover a range of Excel topics like functions, PivotTables, data cleaning, and data visualization.

Return your response as a single, flat JSON array of 10 strings.
Example: ["Question 1?", "Question 2?", ...]
"""

# --- NEW, RADICALLY SIMPLER PROMPT TEMPLATE ---
# The LLM's only job is to ask the question we provide. It does no reasoning.
INTERVIEWER_PROMPT_TEMPLATE = """You are a professional AI interviewer.
Your ONLY task is to ask the user the following question.
Do not add any greetings, commentary, or introductory phrases like "Great" or "Next question".
Just state the question exactly as it is written below.

Question: {next_question}
"""

# --- EVALUATION PROMPT (Unchanged) ---
EVALUATION_PROMPT = """
You are a senior hiring manager. You will be given an interview transcript.
Your task is to provide a single, comprehensive response that includes:
1. A detailed evaluation of the candidate's performance.
2. The candidate's strengths and weaknesses.
3. A clear "HIRE" or "NO HIRE" recommendation.
IMPORTANT: You MUST end your entire response with the exact phrase "EVALUATION_COMPLETE".
"""

# --- Model Client Definition (Unchanged) ---
model_client = OpenAIChatCompletionClient(
    model="gemma2-9b-it",
    base_url="https://api.groq.com/openai/v1",
    api_key='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', # Replace with your key
    model_info={ "vision": False, "function_calling": True, "json_output": True, "family": ModelFamily.UNKNOWN, "structured_output": True, },
    temperature=0.7
)

# --- Factory Functions ---

def create_question_generator_agent():
    """Creates an agent that generates the question list."""
    return AssistantAgent(
        name="question_generator_agent",
        model_client=model_client,
        system_message=QUESTION_GENERATOR_PROMPT
    )

def create_user_agent():
    return UserProxyAgent(name="user")

def create_interviewer_agent(next_question: str):
    """Creates the interviewer agent with a single, specific question to ask."""
    system_prompt = INTERVIEWER_PROMPT_TEMPLATE.format(next_question=next_question)
    return AssistantAgent(
        name="interviewer_agent",
        model_client=model_client,
        system_message=system_prompt
    )

def create_evaluation_agent():
    return AssistantAgent(
        name="evaluation_agent",
        model_client=model_client,
        system_message=EVALUATION_PROMPT
    )

def create_interview_team(next_question: str):
    """Factory that creates a team for the simple task of asking one question."""
    # This team has one job: let the interviewer ask its question.
    return RoundRobinGroupChat(
        participants=[create_interviewer_agent(next_question), create_user_agent()],
    )

def create_evaluation_team():
    return RoundRobinGroupChat(
        participants=[create_evaluation_agent()],
        termination_condition=TextMentionTermination("EVALUATION_COMPLETE")
    )