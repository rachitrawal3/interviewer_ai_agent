import streamlit as st
import asyncio
import uuid
import json
from typing import List

# Import your DB class and the new factory functions
from db2 import InMemoryDB
from interview_agents import (
    create_interview_team,
    create_evaluation_team,
    create_user_agent,
    create_question_generator_agent
)

# New imports required for the modern autogen API
from autogen_core import CancellationToken
from autogen_agentchat.messages import HandoffMessage, TextMessage

# --- Asyncio Event Loop Helper (Unchanged) ---
def run_async_in_st(coro):
    """Safely run async code within Streamlit's sync environment."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    return loop.run_until_complete(coro)

# --- Backend Logic ---

async def generate_questions() -> List[str]:
    """Uses the generator agent's `on_messages` method directly."""
    q_gen_agent = create_question_generator_agent()
    request_message = TextMessage(content="Generate the questions.", source="system")
    response = await q_gen_agent.on_messages(
        messages=[request_message],
        cancellation_token=CancellationToken()
    )
    reply_message = response.chat_message
    try:
        content = reply_message.content
        cleaned_json = content.strip().replace("```json", "").replace("```", "").strip()
        return json.loads(cleaned_json)
    except (json.JSONDecodeError, AttributeError, TypeError) as e:
        st.error(f"Fatal: The question generator failed. Error: {e}. Please refresh and try again.")
        return ["Fallback: What is a PivotTable?", "Fallback: What is VLOOKUP?"]

async def get_next_agent_response(next_question: str) -> TextMessage:
    """
    Creates a team to ask the next question. It is given a single "trigger"
    message to satisfy the autogen API, but NOT the conversation history.
    """
    interview_team = create_interview_team(next_question)
    
    # --- THE CRITICAL FIX ---
    # We create a single, context-free message to kickstart the run_stream.
    # This satisfies the "Task list cannot be empty" requirement and ensures
    # the interviewer_agent (the first in the RoundRobin) speaks first.
    trigger_message = HandoffMessage(source="user", target="interviewer_agent", content="Continue.")
    stream = interview_team.run_stream(task=[trigger_message])

    async for message in stream:
        if isinstance(message, TextMessage) and message.source == "interviewer_agent":
            return message
    return None

async def run_evaluation(full_history: List[TextMessage]) -> str:
    # Unchanged
    if len(full_history) <= 1: return "No meaningful conversation recorded."
    transcript = "INTERVIEW TRANSCRIPT:\n\n"
    for msg in full_history:
        if msg.source in ["interviewer_agent", "user"] and not isinstance(msg, HandoffMessage):
            role = "Interviewer" if msg.source == "interviewer_agent" else "Candidate"
            transcript += f"{role}: {msg.content.strip()}\n"
    evaluation_team = create_evaluation_team()
    task = TextMessage(source="user", target="evaluation_agent", content=transcript)
    async for event in evaluation_team.run_stream(task=task):
        if isinstance(event, TextMessage) and event.source == "evaluation_agent" and event.content:
            return event.content.replace("EVALUATION_COMPLETE", "").strip()
    return "Evaluation failed to generate a response."

# --- Streamlit UI ---
st.set_page_config(page_title="Excel Analyst Interview Bot", layout="centered")
st.title("🤖 Excel Data Analyst Interview Bot")

# --- Initialize Session State ---
if "interview_started" not in st.session_state:
    st.session_state.interview_started = False
    st.session_state.interview_finished = False
    st.session_state.messages = []
    st.session_state.db = InMemoryDB()
    st.session_state.session_id = f"interview_session_{uuid.uuid4()}"
    st.session_state.interview_questions = []
    st.session_state.question_index = 0

# Display chat messages from history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# --- Main App Logic ---

# 1. Start Button Logic
if not st.session_state.interview_started:
    if st.button("Start Interview"):
        st.session_state.interview_started = True
        with st.spinner("Generating a unique set of interview questions..."):
            st.session_state.interview_questions = run_async_in_st(generate_questions())

        if st.session_state.interview_questions:
            db = st.session_state.db
            session_id = st.session_state.session_id
            
            st.session_state.question_index = 0
            first_question_text = st.session_state.interview_questions[0]
            first_question_message = TextMessage(source="interviewer_agent", content=first_question_text)
            bootstrap_message = HandoffMessage(
                source="user", target="interviewer_agent", content="Start the interview."
            )
            db.add_message(session_id, bootstrap_message)
            db.add_message(session_id, first_question_message)
            st.session_state.messages.append({"role": "assistant", "content": first_question_text})
            st.rerun()

# 2. Ongoing Interview Logic
elif not st.session_state.interview_finished:
    if prompt := st.chat_input("Your answer..."):
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        st.session_state.question_index += 1

        if st.session_state.question_index >= len(st.session_state.interview_questions):
            st.session_state.interview_finished = True
            st.rerun()
        else:
            db = st.session_state.db
            session_id = st.session_state.session_id
            user_agent = create_user_agent()
            user_message = TextMessage(source=user_agent.name, content=prompt)
            db.add_message(session_id, user_message)

            with st.spinner("..."):
                next_question_to_ask = st.session_state.interview_questions[st.session_state.question_index]
                
                agent_response = run_async_in_st(get_next_agent_response(next_question_to_ask))

            if agent_response:
                db.add_message(session_id, agent_response)
                st.session_state.messages.append({"role": "assistant", "content": agent_response.content})
            else:
                st.error("The interviewer failed to respond. The interview will now conclude.")
                st.session_state.interview_finished = True
            st.rerun()

# 3. Evaluation Logic (Unchanged)
else:
    st.info("Interview complete. Generating evaluation report...")
    if "evaluation_report" not in st.session_state:
        with st.spinner("Analyzing transcript..."):
            db = st.session_state.db
            session_id = st.session_state.session_id
            full_history = db.get_messages(session_id)
            report = run_async_in_st(run_evaluation(full_history))
            st.session_state.evaluation_report = report
        st.rerun()
    st.subheader("--- Evaluation Result ---")
    st.markdown(st.session_state.evaluation_report)